import java.sql.*;
import java.util.*;
public class Main {
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the CRUD Application!");

        while (true) {
            System.out.println("\nPlease choose an operation:");
            System.out.println("1. Insert a new record");
            System.out.println("2. Retrieve all records");
            System.out.println("3. Update a record");
            System.out.println("4. Delete a record");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Insert a new record
                    System.out.println("\nInsert a New Record:");
                    System.out.print("Enter name: ");
                    String insertName = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String insertPhone = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String insertEmail = scanner.nextLine();
                    DBConnection.insertIntoDB(insertName, insertPhone, insertEmail);
                    break;
                case 2:
                    // Retrieve all records
                    System.out.println("\nRetrieving All Records:");
                    DBConnection.retrieveFromDB();
                    break;
                case 3:
                    // Update a record
                    System.out.println("\nUpdate a Record:");
                    System.out.print("Enter name: ");
                    String updateName = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String updatePhone = scanner.nextLine();
                    System.out.print("Enter new email: ");
                    String updateEmail = scanner.nextLine();
                    DBConnection.updateInDB(updateName, updatePhone, updateEmail);
                    break;
                case 4:
                    // Delete a record
                    System.out.println("\nDelete a Record:");
                    System.out.print("Enter name: ");
                    String deleteName = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String deletePhone = scanner.nextLine();
                    DBConnection.deleteFromDB(deleteName, deletePhone);
                    break;
                case 5:
                    // Exit
                    System.out.println("Exiting the application.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

    }
}

class DBConnection{
    private static Connection connection;
    public static Connection getConection(){
        String url = "jdbc:mysql://localhost:3306/CRUD";
        String username = "root";
        String password = "1234";

        try {
            connection = DriverManager.getConnection(url,username,password);
            if(connection!=null){
                System.out.println("Connection Established!");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return connection;
    }

    public static void insertIntoDB(String name, String phone_number , String email)
    {
        String sql = "INSERT INTO crub_table (name, phone_number, email) VALUES (?, ?, ?)";

        try {
            Connection connection = DBConnection.getConection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, phone_number);
            preparedStatement.setString(3, email);

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new employee was inserted successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to insert data.");
        }
    }

    // Read/Retrieve
    public static void retrieveFromDB() {
        String sql = "SELECT * FROM crub_table";

        try {
            Connection connection = DBConnection.getConection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            System.out.println("Name | Phone Number | Email");
            System.out.println("-----------------------------------");

            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String phoneNumber = resultSet.getString("phone_number");
                String email = resultSet.getString("email");

                System.out.printf("%s | %s | %s%n", name, phoneNumber, email);
            }

            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to retrieve data.");
        }
    }

    // Update
    public static void updateInDB(String name, String phoneNumber, String newEmail) {
        String sql = "UPDATE crub_table SET email = ? WHERE name = ? AND phone_number = ?";

        try {
            Connection connection = DBConnection.getConection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, newEmail);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, phoneNumber);

            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("The record was updated successfully!");
            } else {
                System.out.println("No record found with the given name and phone number.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to update data.");
        }
    }

    // Delete
    public static void deleteFromDB(String name, String phoneNumber) {
        String sql = "DELETE FROM crub_table WHERE name = ? AND phone_number = ?";

        try {
            Connection connection = DBConnection.getConection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, phoneNumber);

            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("The record was deleted successfully!");
            } else {
                System.out.println("No record found with the given name and phone number.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to delete data.");
        }
    }


}