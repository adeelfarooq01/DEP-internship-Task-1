create database CRUD;
use CRUD;
create table CRUB_table(
	name varchar(40),
	phone_number varchar(20),
	email varchar(20)
);